//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MentoHUST.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDR_MANIFEST					1
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MENTOHUST_DIALOG            102
#define IDR_MAINFRAME					128
#define IDI_CERTTING                    129
#define IDI_FAILED                      130
#define IDB_LOGO                        131
#define IDD_USERCFG                     132
#define IDD_CFG                         133
#define IDD_EXTRACFG                    134
#define IDC_EDIT_NAME                   1000
#define IDC_AUTORUN                     1000
#define IDC_TAB                         1000
#define IDC_MYCAPTION                   1000
#define IDC_EDIT_PASS                   1001
#define IDC_AUTOCERT                    1001
#define IDC_SAVE                        1001
#define IDC_EDIT_CAPTION                1001
#define IDC_NICLIST                     1002
#define IDC_AUTOMIN                     1002
#define IDC_MYPACKAGE                   1002
#define IDC_STATE                       1003
#define IDC_SAVEPASS                    1003
#define IDC_EDIT_PATH                   1003
#define IDC_BN_CONNECT                  1004
#define IDC_DHCP                        1004
#define IDC_BN_SCAN                     1004
#define IDC_BN_OUTPUT                   1005
#define IDC_EDIT_ECHO                   1005
#define IDC_BN_CATCH                    1005
#define IDC_BN_OPTION                   1006
#define IDC_EDIT_TIMEOUT                1006
#define IDC_MYMAC                       1006
#define IDC_BN_EXIT                     1007
#define IDC_EDIT_MAC                    1007
#define IDC_ARP_BIND                    1007
#define IDC_NORMAL                      1008
#define IDC_MSGLIST                     1008
#define IDC_MYIP                        1008
#define IDC_RUIJIE                      1009
#define IDC_BN_ABOUT                    1009
#define IDC_IP                          1009
#define IDC_BN_HELP                     1010
#define IDC_BN_CLEAR                    1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
