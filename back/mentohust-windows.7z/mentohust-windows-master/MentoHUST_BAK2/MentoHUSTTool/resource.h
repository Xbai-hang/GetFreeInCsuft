//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MentoHUSTTool.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MENTOHUSTTOOL_DIALOG        102
#define IDS_MSG_CAPTION                 102
#define IDS_FILE_FILTER                 103
#define IDS_HELP_FILE                   104
#define IDS_HELP_ERROR                  105
#define IDS_LOGO_URL                    106
#define IDS_LOGO_TIP                    107
#define IDS_START_CATCH                 108
#define IDS_CANCEL_CATCH                109
#define IDS_NOADAPTER                   110
#define IDS_OPEN_ERROR                  111
#define IDS_FILTER_ERROR                112
#define IDS_FILE_ERROR                  113
#define IDS_RUN_RUIJIE                  114
#define IDS_CATCH_ERROR                 115
#define IDS_STATE_START                 116
#define IDS_STATE_MD5                   117
#define IDS_STATE_STOPPING              118
#define IDS_STATE_STOP                  119
#define IDS_SAVE_ERROR                  120
#define IDS_SAVE_SUCCESS                121
#define IDS_CONTACT                     122
#define IDS_UPDATE                      123
#define IDS_CONTACT_INFO                124
#define IDR_MAINFRAME                   128
#define IDB_LOGO                        129
#define IDC_SC_LOGO                     1000
#define IDC_CB_ADAPTER                  1001
#define IDC_BN_ABOUT                    1004
#define IDC_BN_HELP                     1005
#define IDC_SC_STATE                    1006
#define IDC_BN_START                    1008
#define IDC_SC_CONTACT                  1009
#define IDC_SC_UPDATE                   1010
#define IDC_CK_8021X                    1012
#define IDC_CK_W32N55                   1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
